#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<semaphore.h>
pthread_mutex_t lock;
sem_t na_lock, cl_lock;
int na_count = 0, cl_count = 0;
void * Nready(void * ptr)
{
    pthread_mutex_lock(&lock);
    na_count++;
    printf("na is ready for used....\n");
    if (na_count==1&&cl_count==1)
    {
        printf("NaCl salt is formed....\n");
        na_count--;
        cl_count--;
        sem_post(&na_lock);
        sem_post(&cl_lock);
    }
    pthread_mutex_unlock(&lock);
    sem_wait(&na_lock);
}
void * Cready(void * ptr)
{
    pthread_mutex_lock(&lock);
    cl_count++;
    printf("cl is ready for used....\n");
    if (na_count==1&&cl_count==1)
    {
         printf("NaCl salt is formed....\n");
        na_count--;
        cl_count--;
        sem_post(&na_lock);
        sem_post(&cl_lock);
    }
    pthread_mutex_unlock(&lock);
    sem_wait(&cl_lock);
}
int main()
{
    pthread_t pid1, pid2;
    pthread_create(&pid1, NULL, &Nready, NULL);
    pthread_create(&pid2, NULL, &Cready, NULL);
    pthread_join(pid1, NULL);
    pthread_join(pid2, NULL);
    return 0;
}