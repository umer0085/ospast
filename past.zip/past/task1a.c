#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<sys/wait.h>
int M = 0, N = 0;
int **arr1, **arr2, **result;
void* sum(void*ptr)
{
    int row = *(int *)ptr;
    for (int i = 0; i < N; i++)
    {
        result[row][i] = arr1[row][i] + arr2[row][i];
    }
    pthread_exit(NULL);
}
void display(int**arr)
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            printf("%d  ", arr[i][j]);
        }
        printf("\n");
    }
}
int main(int argc,char*argv[])
{
    M = atoi(argv[1]);
    N = atoi(argv[2]);
    arr1 = (int **)malloc(M * sizeof(int *));
    arr2 = (int **)malloc(M * sizeof(int *));
    result = (int **)malloc(M * sizeof(int *));
    for (int i = 0; i < N; i++)
    {
        arr1[i] = (int *)malloc(N * sizeof(int));
        arr2[i] = (int *)malloc(N * sizeof(int));
        result[i] = (int *)malloc(N * sizeof(int));
    }

    // intilize the arrays random
    srand(time(NULL));
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            arr1[i][j] = rand() % 10;
            arr2[i][j] = rand() % 10;
        }
    }
    int row[M];
    pthread_t pid[M];
    for (int i = 0; i < M; i++)
    {
        row[i] = i;
        pthread_create(&pid[i], NULL, &sum, &row[i]);
    }
    for (int i = 0; i < M; i++)
    {
        pthread_join(pid[i], NULL);
    }
    printf("matrix 1: \n");
    display(arr1);
    printf("Matrix 2: \n");
    display(arr2);
    printf("resultant matrix: \n");
    display(result);

    return 0;
}