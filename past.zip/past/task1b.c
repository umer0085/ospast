#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int factorial = 1;  // Global variable to store the final factorial value
pthread_mutex_t mutex;        // Mutex to protect the factorial variable
int N ,M;
void* calculateFactorial(void* arg) {
    int threadId = *(int *)arg;
    int partialFactorial = 1;

    for (int i = threadId; i <= N; i = i + M)
    {
        partialFactorial *= i;
    }
    printf("Thread %d: Partial factorial = %d\n", threadId, partialFactorial);
    pthread_mutex_lock(&mutex);
    factorial *= partialFactorial;
    pthread_mutex_unlock(&mutex);

    pthread_exit(NULL);
}

int main(int argc, char* argv[]) {
     N = atoi(argv[1]);
     M = atoi(argv[2]);

     if (N < M)
     {
        printf(" N must be greater than or equal to M.\n");
        return 1;
    }

    pthread_t threads[M];
    int threadIds[M];

    pthread_mutex_init(&mutex, NULL);

    // Create M threads
    for (int i = 0; i < M; i++)
    {
        threadIds[i] = i + 1;
        pthread_create(&threads[i], NULL, calculateFactorial, &threadIds[i]);
    }

    // Wait for all threads to complete
    for (int i = 0; i < M; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&mutex);

    printf("Final factorial: %d\n", factorial);

    return 0;
}