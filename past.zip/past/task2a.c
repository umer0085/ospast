#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<sys/wait.h>
#include<semaphore.h>
sem_t men_lock, women_lock;
void *men(void *ptr)
{
    int count = 0;
    while (count!=4)
    {

        sem_wait(&men_lock);
        printf("A man enter in the Masjid \n");
        printf("A man left the Masjid \n");
        sem_post(&men_lock);
        
        count++;
    }
}
void *women(void *ptr)
{
    int count = 0;
    while (count!=4)
    {
            sem_wait(&women_lock);
            printf("A women enter in the Masjid \n");
            printf("A women left the Masjid \n");
            sem_post(&women_lock);
            count++;
    }
}
int main()
{
    sem_init(&men_lock, 0, 1);
    sem_init(&women_lock, 0, 1);
    pthread_t pid1, pid2;
    pthread_create(&pid1, NULL, men, NULL);
    pthread_create(&pid2, NULL, women, NULL);
    pthread_join(pid1, NULL);
    pthread_join(pid2, NULL);
    return 0;
}